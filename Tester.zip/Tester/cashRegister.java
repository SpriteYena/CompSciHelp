/**
  * This program is a cash register program that calculates change based on the user's input of item cost and payment amount.
  */

//import packages
import java.util.Scanner;
import java.text.DecimalFormat;
    
public class cashRegister
{
    public static void main(String [] args)
    {
        //activate Scanner and Decimal Format system
        Scanner scanner = new Scanner(System.in);
        DecimalFormat tensSpace = new DecimalFormat(".##");
        
        //declare cost, payment and change variables
        double cost;
        double amtPaid;
        
        //asks user for item cost
        System.out.println("Enter the item cost: ");
        cost = scanner.nextDouble();

        //asks user for payment
        System.out.println("Enter the payment amount: ");
        amtPaid = scanner.nextDouble();

        //calculate change
        int change = (int)(amtPaid * 100 - cost * 100);
        System.out.printf("Your change is: $");
        System.out.printf("%2.2f", (change / 100.0));
        System.out.println("\n");
        
        //initialize default values if there is no change
        int twenties = 0;
        int tens = 0;
        int fives = 0;
        int ones = 0;
        int quarters = 0;
        int dimes = 0;
        int nickels = 0;
        int pennies = 0;
        
        //initialize new values for change
        if(change > 0)
        {
            twenties = change / 2000;
            change = change % 2000;
                
            tens = change / 1000;
            change = change % 1000;
        
            fives = change / 500;
            change = change % 500;
        
            ones = change / 100;
            change = change % 100;
        
            quarters = change / 25;
            change = change % 25;

            dimes = change / 10;
            change = change % 10;

            nickels = change / 5;
            change = change % 5;

            pennies = change / 1;
            change = change % 1;
        }
        
        //output change in terms of money measurements
        System.out.println("Twenties: " + twenties);
        System.out.println("Tens: " + tens);
        System.out.println("Fives: " + fives);
        System.out.println("Ones: " + ones);
        System.out.println("Quarters: " + quarters);
        System.out.println("Dimes: " + dimes);
        System.out.println("Nickels: " + nickels);
        System.out.println("Pennies: " + pennies);
    }//end of method
}//end of class