/**
  * 
  */

//import package
import java.util.Arrays;
    
public class quakeValues
{ 
    public static void main(String [] args)
    {
        //declare array
        double[] quakeLevels = {5.6, 6.2, 4.0, 5.5, 5.7, 6.1, 7.4, 8.5, 5.5, 6.3, 6.4, 2.1, 6.9, 4.3, 3.1, 7.0, 10.1};
        
        //declare minimum value
        double quakeMin = quakeLevels[0];
        
        //calculate minimum value
        for(int counter = 1; counter < quakeLevels.length; counter++)
        {
            if (quakeLevels[counter] < quakeMin)
            {
                quakeMin = quakeLevels[counter];
            }
        }
        
        //declare maximum value
        double quakeMax = quakeLevels[0];
        
        //calculate maximum value
        for(int counter = 1; counter < quakeLevels.length; counter++)
        {
            if (quakeLevels[counter] > quakeMax)
            {
                quakeMax = quakeLevels[counter];
            }
        }
        
        //output the original array's minimum and maximum values
        System.out.println("The original array's minimum value is: " + quakeMin);
        System.out.println("The original array's maximum value is: " + quakeMax);
        System.out.println("");
        
        //declare new array without minimum and maximum values
        double[] newQuakeLevels = {5.6, 6.2, 4.0, 5.5, 5.7, 6.1, 7.4, 8.5, 5.5, 6.3, 6.4, 6.9, 4.3, 3.1, 7.0};
        
        //declare empty sum and average values
        double quakeSum = 0, quakeAvg = 0;

        //calculate the average of the new array
        for (int counter = 0; counter < newQuakeLevels.length; counter++)
        {
         quakeSum += newQuakeLevels[counter];
        }

        //calculate average of new array
        quakeAvg = (quakeSum / newQuakeLevels.length);
        
        //print the values of the new array
        System.out.println("The values of the new array (excluding the original's minimum and maximum values) are as follows: ");
        System.out.println(Arrays.toString(newQuakeLevels));
        System.out.println("");
        //print the average of the new array
        System.out.println("The new array's average is: " + quakeAvg);
    }//end of main method
}//end of class